package com.kotlin.signity.rahulnotificationcode.fcm;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;


/**
 * Created by rakesh on 14/01/17.
 */

public class FcmService extends FirebaseInstanceIdService {

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        String registrationToken = FirebaseInstanceId.getInstance().getToken();
        try {
            Log.e("FcmServiceDevice_Token", registrationToken);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


